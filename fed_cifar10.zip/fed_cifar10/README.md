# Federated Learning with PyTorch and Flower 
This repo contains an example codebase for training a simple CNN on CIFAR10. 
For each round, the models returned by each client are stored, as well as the combined global model. In addition, a plot is saved showing the data distribution. 

## Data-distribution scenarios

How CIFAR10 is spread across clients is described in an external YAML file, referenced from `pyproject.toml` via the `scenario-config` key (default: [`scenarios/10-clients/default.yaml`](scenarios/10-clients/default.yaml)). This lets you stage exactly the scenarios you want to visualize without touching the code.

Scenarios are grouped by federation size: [`scenarios/10-clients/`](scenarios/10-clients/) (client ids 0–9) and [`scenarios/3-clients/`](scenarios/3-clients/) (client ids 0–2). Pick the folder that matches your `num-supernodes` — the server fails fast if the scenario's client ids don't match the live federation size.

The federation is defined as a list of client **groups**. Each group owns a pool of classes and distributes it among its clients with one strategy:

- `iid` — each class is split equally over the group's clients.
- `dirichlet` — per-class Dirichlet(`alpha`) split (lower alpha = more non-IID).
- `pathological` — each client gets a fixed `num_classes_per_partition` classes.
- `explicit` — per-client class lists (clients may **share** a class; its samples are split between them).

Groups can be mixed in a single run (e.g. clients 0–7 on a Dirichlet split while clients 8–9 are isolated to two classes), and any client can additionally be given **label noise** (a fraction of its labels flipped to a random different class). See the ready-made presets in each size folder — `iid.yaml`, `dirichlet.yaml`, `pathological.yaml`, `mixed.yaml`, `label_noise.yaml` — for a worked example of every form.

Point the run at a different scenario with:

```bash
flwr run . --run-config 'scenario-config="scenarios/10-clients/dirichlet.yaml"'
```

This paper: FedAWA: Adaptive Optimization of Aggregation Weights in Federated Learning Using Client Vectors (https://arxiv.org/pdf/2503.15842) proposes a way of vectorizing client updates, which could be used for visualization. 


## Set up the project

### Dependencies

Install Flower:

```shell
pip install flwr
```

### Install dependencies and project

Install the dependencies defined in `pyproject.toml` as well as the `pytorchexample` package.

```bash
pip install -e .
```

## Run the project

You can run your Flower project in both _simulation_ and _deployment_ mode without making changes to the code. If you are starting with Flower, we recommend you using the _simulation_ mode as it requires fewer components to be launched manually. By default, `flwr run` will make use of the Simulation Engine.

### Run with the Simulation Engine

> [!TIP]
> This example runs faster when the `ClientApp`s have access to a GPU. If your system has one, you can make use of it by configuring the `backend.client-resources` component in your Flower Configuration. Check the [Simulation Engine documentation](https://flower.ai/docs/framework/how-to-run-simulations.html) to learn more about Flower simulations and how to optimize them.

```bash
# Run with the default federation (CPU only)
flwr run .
```

You can also override some of the settings for your `ClientApp` and `ServerApp` defined in `pyproject.toml`. For example:

```bash
flwr run . --run-config "num-server-rounds=5 learning-rate=0.05"
```

> [!TIP]
> For a more detailed walk-through check our [quickstart PyTorch tutorial](https://flower.ai/docs/framework/tutorial-quickstart-pytorch.html)

### Run with the Deployment Engine

Follow this [how-to guide](https://flower.ai/docs/framework/how-to-run-flower-with-deployment-engine.html) to run the same app in this example but with Flower's Deployment Engine. After that, you might be intersted in setting up [secure TLS-enabled communications](https://flower.ai/docs/framework/how-to-enable-tls-connections.html) and [SuperNode authentication](https://flower.ai/docs/framework/how-to-authenticate-supernodes.html) in your federation.

If you are already familiar with how the Deployment Engine works, you may want to learn how to run it using Docker. Check out the [Flower with Docker](https://flower.ai/docs/framework/docker/index.html) documentation.

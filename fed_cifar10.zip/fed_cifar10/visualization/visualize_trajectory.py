"""Build a self-contained HTML report for one federated-learning run.

Reads everything the ServerApp wrote into a run directory — the per-round
global/client weight checkpoints, the centralized evaluation metrics and the
confusion matrices — and renders a single interactive page:

  * accuracy and loss on the CIFAR-10 test set, global model vs every client
  * pairwise cosine alignment of the client update deltas (pre-PCA)
  * the global model's path through weight space (PCA to 3 components)
  * confusion matrices and per-class recall for any round/model

The page is one HTML file with Plotly inlined, so it works offline.
"""

import argparse
import csv
import glob
import html
import json
import os
import re
from pathlib import Path

import numpy as np
import torch
from sklearn.decomposition import PCA

ASSETS = Path(__file__).resolve().parent / "assets"

# Same eight-slot categorical order the page uses, so the swatches in the
# table view match the marks in the charts.
SERIES_LIGHT = [
    "#2a78d6", "#eb6834", "#1baf7a", "#eda100",
    "#e87ba4", "#008300", "#4a3aa7", "#e34948",
]


# --------------------------------------------------------------- run loading


def find_run_dir(outputs_dir: str, run_dir: str | None) -> str | None:
    """Resolve the run to report on, defaulting to the most recent one."""
    if run_dir:
        if os.path.isdir(run_dir):
            return run_dir
        candidate = os.path.join(outputs_dir, run_dir)
        return candidate if os.path.isdir(candidate) else None

    runs = sorted(p for p in glob.glob(os.path.join(outputs_dir, "*")) if os.path.isdir(p))
    return runs[-1] if runs else None


# BatchNorm buffers are not learnable parameters, and they wreck weight-space
# geometry: `running_var` sits at O(1) with a heavy tail while weights sit at
# O(1e-2), and `num_batches_tracked` is a monotone int64 counter in the
# thousands. On a ResNet-50 run they account for 96% and 4% of the variance
# between checkpoints respectively, leaving the 23.5M real weights with 0.0005%
# — so both the PCA and the cosine alignment end up describing the buffers
# instead of the model. Deeper nets have more BN layers, so the contamination
# grows with model size.
BUFFER_KEYS = ("running_mean", "running_var", "num_batches_tracked")


def load_weights(path: str) -> np.ndarray:
    """Flatten a checkpoint's learnable parameters into a single 1D vector."""
    state_dict = torch.load(path, map_location="cpu")
    return np.concatenate([
        v.numpy().flatten()
        for k, v in state_dict.items()
        if not any(k.endswith(suffix) for suffix in BUFFER_KEYS)
    ])


def load_checkpoints(run_path: str):
    """Load every round's global model and client updates from disk."""
    round_dirs = sorted(
        glob.glob(os.path.join(run_path, "round_*")),
        key=lambda p: int(os.path.basename(p).split("_")[1]),
    )

    global_models: list[tuple[int, np.ndarray]] = []
    client_updates: dict[int, dict[int, np.ndarray]] = {}

    for r_dir in round_dirs:
        r_idx = int(os.path.basename(r_dir).split("_")[1])

        gm_path = os.path.join(r_dir, "global_model.pt")
        if not os.path.exists(gm_path):
            print(f"  ! global_model.pt missing in {os.path.basename(r_dir)}, skipping round")
            continue
        global_models.append((r_idx, load_weights(gm_path)))

        # Key by the client id in the filename so a client keeps its identity
        # (and its colour) across rounds regardless of glob order.
        client_updates[r_idx] = {}
        for cp in sorted(glob.glob(os.path.join(r_dir, "client_*_update.pt"))):
            m = re.search(r"client_(\d+)_update\.pt$", os.path.basename(cp))
            if not m:
                print(f"  ! could not parse a client id from {cp}, skipping")
                continue
            client_updates[r_idx][int(m.group(1))] = load_weights(cp)

    return global_models, client_updates


def load_evaluations(run_path: str):
    """Read `centralized_evaluations.csv` into global / per-client series."""
    path = os.path.join(run_path, "centralized_evaluations.csv")
    if not os.path.exists(path):
        return {"global": [], "clients": {}}, []

    def num(value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    rows = []
    with open(path, newline="") as fh:
        for row in csv.DictReader(fh):
            rows.append(row)

    evals = {"global": [], "clients": {}}
    for row in rows:
        rec = {
            "round": int(row["round"]),
            "acc": num(row.get("test_accuracy")),
            "loss": num(row.get("test_loss")),
        }
        if rec["acc"] is None or rec["loss"] is None:
            continue
        if row["model"] == "global":
            evals["global"].append(rec)
        else:
            rec["train_loss"] = num(row.get("train_loss"))
            rec["n"] = num(row.get("num_examples"))
            evals["clients"].setdefault(str(int(row["client_id"])), []).append(rec)

    evals["global"].sort(key=lambda r: r["round"])
    for series in evals["clients"].values():
        series.sort(key=lambda r: r["round"])
    return evals, rows


def load_confusions(run_path: str):
    """Read `confusion_matrices.json`, keyed as "<round>|global" / "<round>|<cid>"."""
    path = os.path.join(run_path, "confusion_matrices.json")
    if not os.path.exists(path):
        return {"class_names": [], "keys": {}}

    with open(path) as fh:
        blob = json.load(fh)

    keys = {}
    for entry in blob.get("evaluations", []):
        who = "global" if entry["model"] == "global" else str(int(entry["client_id"]))
        keys[f"{entry['round']}|{who}"] = entry["matrix"]
    return {"class_names": blob.get("class_names", []), "keys": keys}


# ------------------------------------------------------------- update alignment


def cosine_matrix(vectors: list[np.ndarray]) -> np.ndarray:
    """Full pairwise cosine similarity matrix for a list of 1D vectors."""
    mat = np.vstack(vectors).astype(np.float64)
    norms = np.linalg.norm(mat, axis=1)
    unit = mat / np.where(norms == 0, 1.0, norms)[:, None]
    sim = unit @ unit.T
    # Zero-norm updates carry no direction: leave them undefined rather than fake.
    dead = norms == 0
    sim[dead, :] = np.nan
    sim[:, dead] = np.nan
    return np.clip(sim, -1.0, 1.0)


def build_similarity(global_models, client_updates):
    """Per-round pairwise cosine similarity of client update deltas.

    A client model saved in round r was trained starting from the global model
    of round r-1, so the update delta is (client_r - global_{r-1}).
    """
    gm_by_round = dict(global_models)
    rounds = sorted(gm_by_round)

    per_round = {}  # round -> (client_ids, matrix)
    for i, r in enumerate(rounds):
        if i == 0:
            continue
        gm_prev = gm_by_round[rounds[i - 1]]
        clients = client_updates.get(r, {})
        if len(clients) < 2:
            continue
        client_ids = sorted(clients)
        per_round[r] = (
            client_ids,
            cosine_matrix([clients[cid] - gm_prev for cid in client_ids]),
        )

    # Mean matrix over all rounds, over the union of client ids seen.
    all_ids = sorted({cid for ids, _ in per_round.values() for cid in ids})
    idx = {cid: k for k, cid in enumerate(all_ids)}
    n = len(all_ids)
    total, count = np.zeros((n, n)), np.zeros((n, n))
    for client_ids, mat in per_round.values():
        for a, ca in enumerate(client_ids):
            for b, cb in enumerate(client_ids):
                if np.isnan(mat[a, b]):
                    continue
                total[idx[ca], idx[cb]] += mat[a, b]
                count[idx[ca], idx[cb]] += 1
    with np.errstate(invalid="ignore", divide="ignore"):
        mean_mat = np.where(count > 0, total / np.where(count == 0, 1, count), np.nan)

    return per_round, all_ids, mean_mat


def offdiag_mean(mat: np.ndarray) -> float:
    """Average of the off-diagonal (i.e. genuinely pairwise) entries."""
    n = mat.shape[0]
    if n < 2:
        return float("nan")
    vals = mat[~np.eye(n, dtype=bool)]
    vals = vals[~np.isnan(vals)]
    return float(np.mean(vals)) if vals.size else float("nan")


def write_similarity_csv(path, per_round, all_ids, mean_mat) -> None:
    """Machine-readable twin of the alignment heatmaps."""
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["round", "client_a", "client_b", "cosine_similarity"])
        for r in sorted(per_round):
            client_ids, mat = per_round[r]
            for a, ca in enumerate(client_ids):
                for b, cb in enumerate(client_ids):
                    if b > a and not np.isnan(mat[a, b]):
                        w.writerow([r, ca, cb, f"{mat[a, b]:.6f}"])
        for a, ca in enumerate(all_ids):
            for b, cb in enumerate(all_ids):
                if b > a and not np.isnan(mean_mat[a, b]):
                    w.writerow(["mean", ca, cb, f"{mean_mat[a, b]:.6f}"])


def print_matrix(client_ids, mat, title) -> None:
    print(f"\n{title}")
    print("        " + "".join(f"  C{cid:<6}" for cid in client_ids))
    for i, cid in enumerate(client_ids):
        cells = "".join(
            "  {:<7}".format("  n/a" if np.isnan(v) else f"{v:+.3f}") for v in mat[i]
        )
        print(f"  C{cid:<5}{cells}")


# --------------------------------------------------------------------- payload


def jsonable(mat: np.ndarray) -> list:
    """NaN is not valid JSON; the page renders None as "n/a"."""
    return [[None if np.isnan(v) else round(float(v), 6) for v in row] for row in mat]


def build_payload(run_path, global_models, client_updates, evals, confusion, sim_range):
    per_round, all_ids, mean_mat = build_similarity(global_models, client_updates)

    client_ids = sorted(
        {cid for cm in client_updates.values() for cid in cm}
        | {int(cid) for cid in evals["clients"]}
    )
    rounds = sorted(
        {r for r, _ in global_models}
        | {rec["round"] for rec in evals["global"]}
        | {int(k.split("|")[0]) for k in confusion["keys"]}
    )

    pca_payload = {"explained": [], "global": [], "clients": {}}
    vectors = [gm for _, gm in global_models]
    for c_models in client_updates.values():
        vectors.extend(c_models.values())
    if len(vectors) >= 3:
        pca = PCA(n_components=3).fit(np.array(vectors))
        pca_payload["explained"] = [round(float(v), 4) for v in pca.explained_variance_ratio_]
        pca_payload["global"] = [
            {"round": r, "xyz": [round(float(x), 5) for x in pca.transform([gm])[0]]}
            for r, gm in global_models
        ]
        pca_payload["clients"] = {
            str(r): {
                str(cid): [round(float(x), 5) for x in pca.transform([vec])[0]]
                for cid, vec in c_models.items()
            }
            for r, c_models in client_updates.items()
            if c_models
        }

    if sim_range == "auto" and per_round:
        finite = np.concatenate([m[~np.isnan(m)].ravel() for _, m in per_round.values()])
        bound = float(np.max(np.abs(finite))) if finite.size else 1.0
        srange = [-bound, bound]
    else:
        srange = [-1.0, 1.0]

    name = os.path.basename(os.path.abspath(run_path))
    # Run directories are named "<timestamp>-<model>-<scenario>".
    meta = re.match(r"(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})-([^-]+)-(.+)$", name)

    return {
        "run": {
            "name": name,
            "timestamp": meta.group(1) if meta else "",
            "model": meta.group(2) if meta else "",
            "scenario": meta.group(3) if meta else "",
            "rounds": rounds,
            "client_ids": client_ids,
        },
        "evals": evals,
        "similarity": {
            "mean": ({"ids": all_ids, "matrix": jsonable(mean_mat)} if per_round else None),
            "per_round": {
                str(r): {"ids": ids, "matrix": jsonable(mat)}
                for r, (ids, mat) in per_round.items()
            },
            "trend": [
                {"round": r, "avg": round(offdiag_mean(per_round[r][1]), 6)}
                for r in sorted(per_round)
                if not np.isnan(offdiag_mean(per_round[r][1]))
            ],
            "range": srange,
        },
        "pca": pca_payload,
        "confusion": confusion,
    }, (per_round, all_ids, mean_mat)


# ------------------------------------------------------------------ HTML page


def plotly_source() -> tuple[str, bool]:
    """Return (script tag contents or src url, inlined?)."""
    try:
        from plotly.offline import get_plotlyjs

        return get_plotlyjs(), True
    except Exception:
        return "https://cdn.plot.ly/plotly-2.35.2.min.js", False


def tile(label, value, sub=None, hero=False, delta=None) -> str:
    classes = "tile hero" if hero else "tile"
    parts = [f'<div class="{classes}">', f'<div class="label">{html.escape(label)}</div>']
    parts.append(f'<div class="value">{html.escape(value)}</div>')
    if delta is not None:
        direction = "up" if delta.startswith("+") else "down"
        parts.append(f'<div class="sub delta {direction}">{html.escape(delta)}</div>')
    if sub:
        parts.append(f'<div class="sub">{html.escape(sub)}</div>')
    parts.append("</div>")
    return "".join(parts)


def build_tiles(payload, mean_mat) -> str:
    g = payload["evals"]["global"]
    tiles = []

    if g:
        first, last, best = g[0], g[-1], max(g, key=lambda r: r["acc"])
        tiles.append(tile(
            "Global accuracy, final round",
            f"{last['acc'] * 100:.1f}%",
            sub=f"round {last['round']} · loss {last['loss']:.3f}",
            hero=True,
            delta=f"{(last['acc'] - first['acc']) * 100:+.1f} pp vs round {first['round']}",
        ))
        tiles.append(tile(
            "Best global accuracy",
            f"{best['acc'] * 100:.1f}%",
            sub=f"reached in round {best['round']}",
        ))

    # Client accuracy in the last round every client was evaluated in — the
    # spread is the heterogeneity story in one number.
    per_round_clients: dict[int, list[float]] = {}
    for series in payload["evals"]["clients"].values():
        for rec in series:
            per_round_clients.setdefault(rec["round"], []).append(rec["acc"])
    if per_round_clients:
        r = max(per_round_clients)
        accs = per_round_clients[r]
        tiles.append(tile(
            "Client updates, final round",
            f"{min(accs) * 100:.0f}–{max(accs) * 100:.0f}%",
            sub=f"{len(accs)} clients scored centrally in round {r} · "
                f"mean {sum(accs) / len(accs) * 100:.1f}%",
        ))

    if mean_mat is not None and mean_mat.size:
        avg = offdiag_mean(mean_mat)
        if not np.isnan(avg):
            tiles.append(tile(
                "Mean update alignment",
                f"{avg:+.3f}",
                sub="pairwise cosine of client deltas, averaged over rounds",
            ))

    return f'<div class="tiles">{"".join(tiles)}</div>' if tiles else ""


def build_filters(payload) -> str:
    rounds = payload["run"]["rounds"]
    if not rounds:
        return ""
    max_idx = len(rounds) - 1
    last_round = rounds[-1]

    models = ['<option value="global">Global model</option>']
    have = {k.split("|")[1] for k in payload["confusion"]["keys"]}
    for cid in payload["run"]["client_ids"]:
        if str(cid) in have:
            models.append(f'<option value="{cid}">Client {cid}</option>')

    return f"""
    <div class="filters">
      <div class="field">
        <label for="sel-round">Round <strong id="round-val">{last_round}</strong></label>
        <input type="range" id="sel-round" min="0" max="{max_idx}" step="1" value="{max_idx}">
      </div>
      <div class="field"><label for="sel-model">Confusion matrix for</label>
        <select id="sel-model">{"".join(models)}</select></div>
      <div class="field"><span>Cell values</span>
        <span class="segmented">
          <button type="button" data-norm="counts" aria-pressed="true">Counts</button>
          <button type="button" data-norm="row" aria-pressed="false">Row %</button>
        </span></div>
      <div class="note">Scopes the alignment and confusion panels below.</div>
    </div>"""


def build_table(rows, payload) -> str:
    """Table-view twin of the charts (nothing is locked behind hover)."""
    if not rows:
        return ""
    order = {str(cid): i for i, cid in enumerate(payload["run"]["client_ids"])}

    body = []
    for row in sorted(rows, key=lambda r: (int(r["round"]), r["model"] != "global",
                                           r.get("client_id") or "")):
        if row["model"] == "global":
            who, swatch = "Global model", "var(--text-primary)"
        else:
            cid = str(int(row["client_id"]))
            who = f"Client {cid}"
            swatch = SERIES_LIGHT[order.get(cid, 0) % 8]

        def fmt(key, spec):
            value = row.get(key) or ""
            try:
                return format(float(value), spec)
            except (TypeError, ValueError):
                return "—"

        body.append(
            f"<tr><td><span class=\"swatch\" style=\"background:{swatch}\"></span>"
            f"{html.escape(who)}</td>"
            f"<td>{html.escape(str(row['round']))}</td>"
            f"<td>{fmt('test_accuracy', '.2%')}</td>"
            f"<td>{fmt('test_loss', '.4f')}</td>"
            f"<td>{fmt('train_loss', '.4f')}</td>"
            f"<td>{fmt('num_examples', ',.0f')}</td></tr>"
        )

    return f"""
    <details class="table-view">
      <summary>Table view — every centralized evaluation</summary>
      <div class="table-scroll">
        <table>
          <thead><tr>
            <th>Model</th><th>Round</th><th>Test accuracy</th>
            <th>Test loss</th><th>Local train loss</th><th>Local train images</th>
          </tr></thead>
          <tbody>{"".join(body)}</tbody>
        </table>
      </div>
    </details>"""


def build_similarity_table(all_ids, mean_mat) -> str:
    if mean_mat is None or not mean_mat.size:
        return ""
    head = "".join(f"<th>C{cid}</th>" for cid in all_ids)
    body = []
    for i, cid in enumerate(all_ids):
        cells = "".join(
            f"<td>{'—' if np.isnan(v) else format(v, '+.3f')}</td>" for v in mean_mat[i]
        )
        body.append(f"<tr><td>C{cid}</td>{cells}</tr>")
    return f"""
    <details class="table-view" style="margin-top:14px">
      <summary>Table view — mean pairwise cosine similarity</summary>
      <div class="table-scroll">
        <table>
          <thead><tr><th></th>{head}</tr></thead>
          <tbody>{"".join(body)}</tbody>
        </table>
      </div>
    </details>"""


def render_html(payload, rows, similarity, out_path) -> None:
    per_round, all_ids, mean_mat = similarity
    run = payload["run"]

    chips = []
    if run["model"]:
        chips.append(f"model {run['model']}")
    if run["scenario"]:
        chips.append(f"scenario {run['scenario'].replace('_', ' / ')}")
    chips.append(f"{len(run['client_ids'])} clients")
    chips.append(f"{len(run['rounds'])} rounds evaluated")
    if run["timestamp"]:
        chips.append(run["timestamp"].replace("_", " "))
    chip_html = "".join(f'<span class="chip">{html.escape(c)}</span>' for c in chips)

    has_evals = bool(payload["evals"]["global"] or payload["evals"]["clients"])
    has_sim = payload["similarity"]["mean"] is not None
    has_pca = bool(payload["pca"]["global"])
    has_conf = bool(payload["confusion"]["keys"])

    sections = []

    if has_evals:
        sections.append("""
    <section>
      <h2>Performance on the CIFAR-10 test set</h2>
      <p class="lede">Every model is scored on the same held-out 10,000 images:
        the aggregated global model of each round, and each client's update
        before aggregation. A client that scores far below the global model has
        specialised to its own partition.</p>
      <div class="row two">
        <div class="card">
          <h3>Test accuracy by round</h3>
          <p class="sub">Global model in ink; client updates in their own colour.</p>
          <div class="plot" id="fig-accuracy" style="height:340px"></div>
        </div>
        <div class="card">
          <h3>Test loss by round</h3>
          <p class="sub">Cross-entropy on the same 10,000 images.</p>
          <div class="plot" id="fig-loss" style="height:340px"></div>
        </div>
      </div>
    </section>""")

    if has_sim:
        sections.append(f"""
    <section>
      <h2>Client update alignment</h2>
      <p class="lede">Cosine similarity between client update deltas
        (client<sub>r</sub> − global<sub>r−1</sub>), measured in the full
        weight space before any dimensionality reduction. IID clients pull in
        roughly the same direction (positive); non-IID clients diverge
        (near zero or negative).</p>
      <div class="row sim">
        <div class="card">
          <h3>Averaged over all rounds</h3>
          <p class="sub">The run's overall alignment between each pair of clients.</p>
          <div class="plot" id="fig-sim-mean" style="height:{max(300, 46 * len(all_ids) + 120)}px"></div>
        </div>
        <div class="card">
          <h3>Selected round</h3>
          <p class="sub" id="sim-round-note">Round</p>
          <div class="plot" id="fig-sim-round" style="height:{max(300, 46 * len(all_ids) + 120)}px"></div>
        </div>
      </div>
      <div class="row" style="margin-top:18px">
        <div class="card">
          <h3>Mean pairwise alignment per round</h3>
          <p class="sub">Off-diagonal average of the matrix above, round by round.</p>
          <div class="plot" id="fig-sim-trend" style="height:250px"></div>
        </div>
      </div>
      {build_similarity_table(all_ids, mean_mat)}
    </section>""")

    if has_pca:
        explained = payload["pca"]["explained"]
        share = f"{sum(explained) * 100:.1f}%" if explained else "—"
        sections.append(f"""
    <section>
      <h2>Trajectory through weight space</h2>
      <p class="lede">Every checkpoint — global models and client updates — projected
        onto the same three principal components ({share} of the variance
        between them). Dotted lines run from the global model a client started
        from to where its local training took it. Drag to rotate.</p>
      <div class="row">
        <div class="card">
          <h3>Global path and client pulls (PCA)</h3>
          <p class="sub">PC 1–3 explain
            {" · ".join(f"{v * 100:.1f}%" for v in explained) if explained else "—"}
            of the variance.</p>
          <div class="plot" id="fig-trajectory" style="height:620px"></div>
        </div>
      </div>
    </section>""")

    if has_conf:
        sections.append("""
    <section>
      <h2>Confusion matrix</h2>
      <p class="lede">Which classes the selected model gets right and what it
        mistakes them for. Rows are true labels, columns are predictions, so the
        diagonal is correct. Use the selectors above to switch round and model.</p>
      <div class="row conf">
        <div class="card">
          <h3>Predictions vs truth</h3>
          <p class="sub" id="conf-caption"></p>
          <div class="plot" id="fig-confusion" style="height:520px"></div>
        </div>
        <div class="card">
          <h3>Recall per class</h3>
          <p class="sub">Share of each class's test images the model recovers.</p>
          <div class="plot" id="fig-recall" style="height:520px"></div>
        </div>
      </div>
    </section>""")

    if not sections:
        sections.append('<section><p class="empty">Nothing to report: this run '
                        "directory has no checkpoints or evaluation files.</p></section>")

    css = (ASSETS / "report.css").read_text()
    js = (ASSETS / "report.js").read_text()
    plotly, inlined = plotly_source()
    plotly_tag = (f"<script>{plotly}</script>" if inlined
                  else f'<script src="{plotly}" charset="utf-8"></script>')

    # `</script>` inside the payload would close the tag early.
    payload_json = json.dumps(payload).replace("</", "<\\/")

    document = f"""<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{html.escape(run["name"])} — federated run report</title>
<style>{css}</style>
{plotly_tag}
</head>
<body>
<div class="wrap">
  <header class="page">
    <div>
      <h1>Federated run report</h1>
      <div class="run-meta">{chip_html}</div>
    </div>
    <button type="button" class="theme-toggle" id="theme-toggle">Dark theme</button>
  </header>

  {build_tiles(payload, mean_mat if has_sim else None)}
  {build_filters(payload) if (has_sim or has_conf) else ""}
  {"".join(sections)}

  {build_table(rows, payload)}

  <footer class="page">
    Built from <code>{html.escape(run["name"])}</code> ·
    metrics from <code>centralized_evaluations.csv</code> ·
    matrices from <code>confusion_matrices.json</code> ·
    alignment from the per-round <code>*.pt</code> checkpoints
    (also written to <code>client_similarity.csv</code>).
  </footer>
</div>
<script>window.__FL_PAYLOAD__ = {payload_json};</script>
<script>{js}</script>
</body>
</html>
"""
    with open(out_path, "w") as fh:
        fh.write(document)


# ------------------------------------------------------------------------ main


def main() -> None:
    default_outputs = "outputs" if os.path.isdir("outputs") else "../outputs"
    parser = argparse.ArgumentParser(
        description="Build an interactive HTML report for a federated learning run."
    )
    parser.add_argument("--outputs-dir", default=default_outputs,
                        help=f"base outputs directory (default: {default_outputs})")
    parser.add_argument("--run-dir", default=None,
                        help="run directory or run name (default: the most recent run)")
    parser.add_argument("--sim-range", choices=["full", "auto"], default="full",
                        help="colour range for the similarity matrices: 'full' fixes it "
                             "at [-1, 1] (comparable across runs), 'auto' scales "
                             "symmetrically to the largest observed magnitude")
    parser.add_argument("--output", default=None,
                        help="report filename, written inside the run directory "
                             "(default: the run directory's name + '.html', so the "
                             "file stays self-describing once downloaded)")
    args = parser.parse_args()

    run_path = find_run_dir(args.outputs_dir, args.run_dir)
    if not run_path:
        print(f"No run directory found in {args.outputs_dir}")
        return
    print(f"Run: {run_path}")

    global_models, client_updates = load_checkpoints(run_path)
    evals, rows = load_evaluations(run_path)
    confusion = load_confusions(run_path)

    if not global_models and not rows:
        print("Nothing to visualize: no round checkpoints and no evaluation CSV.")
        return

    print(f"  checkpoints: {len(global_models)} global model(s), "
          f"{sum(len(c) for c in client_updates.values())} client update(s)")
    print(f"  evaluations: {len(rows)} row(s), "
          f"{len(confusion['keys'])} confusion matrix/matrices")

    payload, similarity = build_payload(
        run_path, global_models, client_updates, evals, confusion, args.sim_range
    )
    per_round, all_ids, mean_mat = similarity

    if per_round:
        for r in sorted(per_round):
            client_ids, mat = per_round[r]
            print_matrix(client_ids, mat,
                         f"Round {r}  (mean pairwise = {offdiag_mean(mat):+.4f})")
        print_matrix(all_ids, mean_mat,
                     f"Mean over rounds  (mean pairwise = {offdiag_mean(mean_mat):+.4f})")
        csv_path = os.path.join(run_path, "client_similarity.csv")
        write_similarity_csv(csv_path, per_round, all_ids, mean_mat)
        print(f"\nSimilarity table → {csv_path}")
    elif global_models:
        print("\nNot enough clients per round (need >= 2) for pairwise similarity.")

    out_name = args.output or f"{os.path.basename(os.path.normpath(run_path))}.html"
    out_path = os.path.join(run_path, out_name)
    render_html(payload, rows, similarity, out_path)
    print(f"Report → {out_path}")


if __name__ == "__main__":
    main()

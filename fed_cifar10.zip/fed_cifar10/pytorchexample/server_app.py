"""pytorchexample: A Flower / PyTorch app."""

import csv
import datetime
import json
import os
import shutil
from collections.abc import Iterable
from pathlib import Path

import torch
from flwr.app import ArrayRecord, ConfigRecord, Context, MetricRecord
from flwr.common import Message
from flwr.serverapp import Grid, ServerApp
from flwr.serverapp.strategy import FedAvg

from pytorchexample.task import (
    CIFAR10_CLASSES,
    _resolve_scenario_path,
    evaluate,
    get_model,
    load_centralized_dataset,
    plot_partition_distribution,
    scenario_client_ids,
)

# Columns of `centralized_evaluations.csv`. One row per model evaluated on the
# full CIFAR-10 test set: the aggregated global model of a round, and every
# individual client update that went into it.
EVAL_CSV_FIELDS = [
    "round",
    "model",  # "global" | "client"
    "client_id",  # partition id on client rows, empty on global rows
    "test_loss",
    "test_accuracy",
    "num_examples",  # client's local train-set size (empty on global rows)
    "train_loss",  # client's local training loss (empty on global rows)
]


class LoggingFedAvg(FedAvg):
    """FedAvg strategy that logs all client model updates and the aggregated
    global model to disk after each training round, and scores each of them on
    the centralized CIFAR-10 test set."""

    def __init__(
        self,
        log_dir: str = "federation_logs",
        model_name: str = "cnn",
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.log_dir = log_dir
        self.model_name = model_name
        os.makedirs(self.log_dir, exist_ok=True)

        # Scalar metrics stream into a CSV; the 10x10 confusion matrices go to a
        # companion JSON, both keyed by (round, model, client_id).
        self.eval_csv_path = os.path.join(self.log_dir, "centralized_evaluations.csv")
        with open(self.eval_csv_path, "w", newline="") as fh:
            csv.writer(fh).writerow(EVAL_CSV_FIELDS)
        self.confusion_path = os.path.join(self.log_dir, "confusion_matrices.json")
        self._confusions: list[dict] = []

        self.device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        # Build the scoring model and test set once and reuse them: a run
        # evaluates (num_clients + 1) models per round.
        self._eval_model = get_model(model_name).to(self.device)
        self._test_dataloader = None

    def _evaluate_state_dict(self, state_dict):
        """Score a state dict on the full centralized CIFAR-10 test set."""
        if self._test_dataloader is None:
            self._test_dataloader = load_centralized_dataset()
        self._eval_model.load_state_dict(state_dict)
        return evaluate(
            self._eval_model,
            self._test_dataloader,
            self.device,
            num_classes=len(CIFAR10_CLASSES),
        )

    def _record_evaluation(self, confusion, **row) -> None:
        """Append one evaluation to the CSV and the confusion-matrix JSON.

        Both files are flushed immediately so an interrupted run still leaves
        usable results behind.
        """
        with open(self.eval_csv_path, "a", newline="") as fh:
            csv.DictWriter(fh, fieldnames=EVAL_CSV_FIELDS).writerow(
                {field: row.get(field, "") for field in EVAL_CSV_FIELDS}
            )

        self._confusions.append(
            {
                "round": row["round"],
                "model": row["model"],
                "client_id": row.get("client_id", None),
                # Rows = true label, columns = predicted label, in
                # `class_names` order.
                "matrix": confusion.tolist(),
            }
        )
        with open(self.confusion_path, "w") as fh:
            json.dump(
                {
                    "class_names": CIFAR10_CLASSES,
                    "axes": {"rows": "true_label", "columns": "predicted_label"},
                    "evaluations": self._confusions,
                },
                fh,
                indent=2,
            )

    def evaluate_global(self, server_round: int, arrays: ArrayRecord) -> MetricRecord:
        """`evaluate_fn` for the strategy: score the global model centrally and
        log the result alongside the client scores."""
        state_dict = arrays.to_torch_state_dict()

        # Round 0 is the initial model, which `aggregate_train` never sees. Save
        # it so the round-1 client updates have a starting point to be measured
        # against in the visualization.
        round_dir = os.path.join(self.log_dir, f"round_{server_round}")
        global_path = os.path.join(round_dir, "global_model.pt")
        if not os.path.exists(global_path):
            os.makedirs(round_dir, exist_ok=True)
            torch.save(state_dict, global_path)
            print(f"[LoggingFedAvg] Saved global model → {global_path}")

        loss, accuracy, confusion = self._evaluate_state_dict(state_dict)
        self._record_evaluation(
            confusion,
            round=server_round,
            model="global",
            test_loss=f"{loss:.6f}",
            test_accuracy=f"{accuracy:.6f}",
        )
        print(
            f"[LoggingFedAvg] Round {server_round} global model: "
            f"acc={accuracy:.4f} loss={loss:.4f}"
        )
        return MetricRecord({"accuracy": accuracy, "loss": loss})

    def aggregate_train(
        self,
        server_round: int,
        replies: Iterable[Message],
    ) -> tuple[ArrayRecord | None, MetricRecord | None]:
        """Override aggregate_train to save and centrally evaluate the client
        updates, and save the new global model, before returning."""

        # Materialise replies so we can iterate twice
        replies = list(replies)

        # --- Save and evaluate individual client model updates ---
        round_dir = os.path.join(self.log_dir, f"round_{server_round}")
        os.makedirs(round_dir, exist_ok=True)

        for msg in replies:
            if msg.has_error():
                continue

            # Extract partition_id from metrics if available, else fallback to node_id
            metrics_record = msg.content.get("metrics")
            partition_id = str(msg.metadata.src_node_id)
            if metrics_record and "partition-id" in metrics_record:
                partition_id = str(int(metrics_record["partition-id"]))

            client_arrays: ArrayRecord = msg.content[self.arrayrecord_key]
            state_dict = client_arrays.to_torch_state_dict()
            path = os.path.join(round_dir, f"client_{partition_id}_update.pt")
            torch.save(state_dict, path)
            print(f"[LoggingFedAvg] Saved client {partition_id} update → {path}")

            loss, accuracy, confusion = self._evaluate_state_dict(state_dict)
            self._record_evaluation(
                confusion,
                round=server_round,
                model="client",
                client_id=partition_id,
                test_loss=f"{loss:.6f}",
                test_accuracy=f"{accuracy:.6f}",
                num_examples=(
                    int(metrics_record["num-examples"])
                    if metrics_record and "num-examples" in metrics_record
                    else ""
                ),
                train_loss=(
                    f"{float(metrics_record['train_loss']):.6f}"
                    if metrics_record and "train_loss" in metrics_record
                    else ""
                ),
            )
            print(
                f"[LoggingFedAvg] Round {server_round} client {partition_id} "
                f"on central test set: acc={accuracy:.4f} loss={loss:.4f}"
            )

        # --- Run the standard FedAvg aggregation ---
        aggregated_arrays, metrics = super().aggregate_train(server_round, replies)

        # --- Save the new global (aggregated) model ---
        # It is scored by `evaluate_global`, which the strategy calls with these
        # same arrays right after this method returns.
        if aggregated_arrays is not None:
            global_state_dict = aggregated_arrays.to_torch_state_dict()
            global_path = os.path.join(round_dir, "global_model.pt")
            torch.save(global_state_dict, global_path)
            print(f"[LoggingFedAvg] Saved global model → {global_path}")

        return aggregated_arrays, metrics


# Create ServerApp
app = ServerApp()


@app.main()
def main(grid: Grid, context: Context) -> None:
    """Main entry point for the ServerApp."""

    # Read run config
    fraction_evaluate: float = context.run_config["fraction-evaluate"]
    num_rounds: int = context.run_config["num-server-rounds"]
    lr: float = context.run_config["learning-rate"]
    scenario_config: str = context.run_config["scenario-config"]
    output_dir_base: str = context.run_config["output-dir"]
    model_name: str = context.run_config["model-name"]

    # Determine the number of supernodes from the grid
    num_supernodes = len(list(grid.get_node_ids()))

    # Fail fast if the federation size does not match the scenario's clients.
    expected_clients = scenario_client_ids(scenario_config)
    if expected_clients != set(range(num_supernodes)):
        raise RuntimeError(
            f"Scenario '{scenario_config}' defines clients "
            f"{sorted(expected_clients)}, but the federation has {num_supernodes} "
            f"supernode(s) (expected client ids 0..{num_supernodes - 1}). "
            "Set num-supernodes in your Flower federation config to match the "
            "scenario, or edit the scenario's client groups."
        )

    # Create a subdirectory for this experiment, named "[date]-[model]-[configname]".
    # `configname` combines the scenario's size folder and file stem so runs
    # stay distinguishable (e.g. "2026-07-24_15-30-05-cnn-10-clients_default").
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    scenario_path = Path(scenario_config)
    config_name = f"{scenario_path.parent.name}_{scenario_path.stem}"
    log_dir = os.path.join(output_dir_base, f"{timestamp}-{model_name}-{config_name}")
    os.makedirs(log_dir, exist_ok=True)
    print(f"[Server] Experiment results will be stored in: {log_dir}")

    # Copy the scenario config into the output folder for reference.
    resolved_scenario = _resolve_scenario_path(scenario_config)
    shutil.copy2(resolved_scenario, os.path.join(log_dir, resolved_scenario.name))
    print(f"[Server] Copied scenario config → {log_dir}/{resolved_scenario.name}")

    # Plot how classes are distributed over clients
    plot_partition_distribution(
        num_partitions=num_supernodes,
        scenario_config_path=scenario_config,
        save_path=os.path.join(log_dir, "partition_distribution.png"),
    )

    # Load global model
    global_model = get_model(model_name)
    arrays = ArrayRecord(global_model.state_dict())

    # Initialize LoggingFedAvg strategy
    strategy = LoggingFedAvg(
        log_dir=log_dir,
        model_name=model_name,
        fraction_evaluate=fraction_evaluate,
    )

    # Start strategy, run FedAvg for `num_rounds`. `evaluate_global` scores the
    # global model on the central test set and records it next to the per-client
    # scores written during aggregation.
    result = strategy.start(
        grid=grid,
        initial_arrays=arrays,
        train_config=ConfigRecord({"lr": lr}),
        num_rounds=num_rounds,
        evaluate_fn=strategy.evaluate_global,
    )

    print(f"\n[Server] Centralized metrics → {strategy.eval_csv_path}")
    print(f"[Server] Confusion matrices → {strategy.confusion_path}")

    # Save final model to disk
    print("\nSaving final model to disk...")
    state_dict = result.arrays.to_torch_state_dict()
    torch.save(state_dict, os.path.join(log_dir, "final_model.pt"))

"""pytorchexample: A Flower / PyTorch app."""

from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import yaml
from datasets import Dataset, load_dataset
from flwr_datasets import FederatedDataset
from flwr_datasets.partitioner import Partitioner
from flwr_datasets.visualization import plot_label_distributions
from torch.utils.data import DataLoader
from torchvision.models import resnet18, resnet50
from torchvision.transforms import Compose, Normalize, ToTensor


class Net(nn.Module):
    """Model (simple CNN adapted from 'PyTorch: A 60 Minute Blitz')"""

    def __init__(self):
        super(Net, self).__init__()
        self.conv1 = nn.Conv2d(3, 6, 5)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = x.view(-1, 16 * 5 * 5)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)


def _cifar_resnet(builder, num_classes: int = 10) -> nn.Module:
    """Build a torchvision ResNet adapted for 32x32 CIFAR-style input.

    Standard torchvision ResNets assume ImageNet-sized (224x224) input: their
    stem downsamples by 4x (7x7 stride-2 conv + maxpool) before the residual
    stages even start, which shrinks CIFAR's 32x32 images too aggressively.
    We swap in the 3x3 stride-1 stem and drop the maxpool, matching the
    common CIFAR-ResNet adaptation.
    """
    model = builder(weights=None, num_classes=num_classes)
    model.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
    model.maxpool = nn.Identity()
    return model


_MODEL_REGISTRY = {
    "cnn": lambda: Net(),
    "resnet18": lambda: _cifar_resnet(resnet18),
    "resnet50": lambda: _cifar_resnet(resnet50),
}


def get_model(model_name: str) -> nn.Module:
    """Instantiate a model by name (see `pyproject.toml`'s `model-name` config)."""
    try:
        return _MODEL_REGISTRY[model_name]()
    except KeyError:
        raise ValueError(
            f"Unknown model-name {model_name!r}. Available options: "
            f"{sorted(_MODEL_REGISTRY)}"
        ) from None


fds = None  # Cache FederatedDataset
_fds_key = None  # (scenario path, num_partitions) the cached `fds` was built for
_scenario_cache: dict = {}  # (scenario path, num_partitions) -> validated scenario dict

pytorch_transforms = Compose([ToTensor(), Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

# CIFAR-10 label order, so saved confusion matrices are human-interpretable.
CIFAR10_CLASSES = [
    "airplane",
    "automobile",
    "bird",
    "cat",
    "deer",
    "dog",
    "frog",
    "horse",
    "ship",
    "truck",
]


def apply_transforms(batch):
    """Apply transforms to the partition from FederatedDataset."""
    batch["img"] = [pytorch_transforms(img) for img in batch["img"]]
    return batch


_VALID_STRATEGIES = {"iid", "dirichlet", "pathological", "explicit"}
_VALID_ASSIGNMENT_MODES = {"random", "deterministic", "first-deterministic"}


def _resolve_scenario_path(path: str) -> Path:
    """Resolve a scenario-config path, trying cwd first then the app root.

    Flower runs with the app root (where ``pyproject.toml`` lives) as cwd, but
    standalone helper scripts may run from elsewhere, so we also try a path
    relative to the package's parent directory.
    """
    candidates = [Path(path)]
    if not Path(path).is_absolute():
        app_root = Path(__file__).resolve().parent.parent
        candidates.append(app_root / path)
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        f"Could not find scenario config '{path}'. Tried: "
        + ", ".join(str(c) for c in candidates)
    )


def _group_class_pool(group: dict) -> list[int]:
    """Return the sorted set of classes a group owns."""
    if group["strategy"] == "explicit":
        pool: set[int] = set()
        for classes in group["assignment"].values():
            pool.update(classes)
        return sorted(pool)
    return sorted(group["classes"])


def _validate_scenario(scenario: dict, num_partitions: int) -> None:
    """Validate a parsed scenario against the federation size.

    Raises ValueError with an actionable message on any inconsistency.
    """
    groups = scenario.get("groups")
    if not isinstance(groups, list) or not groups:
        raise ValueError("Scenario config must define a non-empty 'groups' list.")

    num_classes = scenario["num_classes"]
    seen_clients: dict[int, int] = {}  # client id -> group index that claimed it
    seen_classes: dict[int, int] = {}  # class id -> group index that claimed it

    for gi, group in enumerate(groups):
        strategy = group.get("strategy")
        if strategy not in _VALID_STRATEGIES:
            raise ValueError(
                f"Group {gi}: strategy must be one of {sorted(_VALID_STRATEGIES)}, "
                f"got {strategy!r}."
            )

        clients = group.get("clients")
        if not isinstance(clients, list) or not clients:
            raise ValueError(f"Group {gi}: 'clients' must be a non-empty list.")

        # Strategy-specific required keys.
        if strategy == "dirichlet" and "alpha" not in group:
            raise ValueError(f"Group {gi}: dirichlet strategy requires 'alpha'.")
        if strategy == "pathological":
            if "num_classes_per_partition" not in group:
                raise ValueError(
                    f"Group {gi}: pathological strategy requires "
                    "'num_classes_per_partition'."
                )
            mode = group.get("class_assignment_mode", "deterministic")
            if mode not in _VALID_ASSIGNMENT_MODES:
                raise ValueError(
                    f"Group {gi}: class_assignment_mode must be one of "
                    f"{sorted(_VALID_ASSIGNMENT_MODES)}, got {mode!r}."
                )
        if strategy == "explicit":
            assignment = group.get("assignment")
            if not isinstance(assignment, dict) or not assignment:
                raise ValueError(
                    f"Group {gi}: explicit strategy requires an 'assignment' mapping."
                )
            if set(assignment.keys()) != set(clients):
                raise ValueError(
                    f"Group {gi}: 'assignment' keys {sorted(assignment.keys())} must "
                    f"match 'clients' {sorted(clients)}."
                )
        elif "classes" not in group:
            raise ValueError(f"Group {gi}: strategy {strategy!r} requires 'classes'.")

        # Client uniqueness and range.
        for cid in clients:
            if not isinstance(cid, int) or cid < 0 or cid >= num_partitions:
                raise ValueError(
                    f"Group {gi}: client id {cid} is out of range "
                    f"[0, {num_partitions})."
                )
            if cid in seen_clients:
                raise ValueError(
                    f"Client {cid} appears in groups {seen_clients[cid]} and {gi}; "
                    "client sets must be disjoint."
                )
            seen_clients[cid] = gi

        # Class-pool uniqueness and range.
        for cls in _group_class_pool(group):
            if not isinstance(cls, int) or cls < 0 or cls >= num_classes:
                raise ValueError(
                    f"Group {gi}: class {cls} is out of range [0, {num_classes})."
                )
            if cls in seen_classes:
                raise ValueError(
                    f"Class {cls} is owned by groups {seen_classes[cls]} and {gi}; "
                    "class pools must be disjoint across groups (share within a group)."
                )
            seen_classes[cls] = gi

    missing = set(range(num_partitions)) - set(seen_clients)
    if missing:
        raise ValueError(
            f"Clients {sorted(missing)} are not assigned to any group. Every client "
            f"in [0, {num_partitions}) must appear in exactly one group."
        )

    for cid, frac in scenario["label_noise"].items():
        if not isinstance(cid, int) or cid < 0 or cid >= num_partitions:
            raise ValueError(
                f"label_noise: client id {cid} is out of range [0, {num_partitions})."
            )
        if not 0.0 <= float(frac) <= 1.0:
            raise ValueError(
                f"label_noise[{cid}]: fraction {frac} must be in [0.0, 1.0]."
            )


def load_scenario_config(path: str, num_partitions: int) -> dict:
    """Load, default, validate and cache a scenario YAML file."""
    resolved = _resolve_scenario_path(path)
    cache_key = (str(resolved), num_partitions)
    if cache_key in _scenario_cache:
        return _scenario_cache[cache_key]

    with open(resolved) as fh:
        scenario = yaml.safe_load(fh) or {}

    # Apply defaults.
    scenario.setdefault("seed", 42)
    scenario.setdefault("num_classes", 10)
    scenario.setdefault("label_noise", {})
    if scenario["label_noise"] is None:
        scenario["label_noise"] = {}

    _validate_scenario(scenario, num_partitions)
    _scenario_cache[cache_key] = scenario
    return scenario


def scenario_client_ids(path: str) -> set[int]:
    """Return the set of client ids a scenario references (no validation).

    Used by the ServerApp to check the scenario against the live federation size
    before any training happens.
    """
    resolved = _resolve_scenario_path(path)
    with open(resolved) as fh:
        scenario = yaml.safe_load(fh) or {}
    clients: set[int] = set()
    for group in scenario.get("groups", []) or []:
        clients.update(group.get("clients", []) or [])
    return clients


class ScenarioPartitioner(Partitioner):
    """Partition a dataset according to a group-based scenario spec.

    Each group owns a pool of classes and distributes that pool among its
    clients with one strategy (iid / dirichlet / pathological / explicit).
    A single global client -> sample-index assignment is computed lazily the
    first time a partition is requested, so shared classes are split without
    duplicating samples.
    """

    def __init__(self, num_partitions: int, groups: list[dict], seed: int = 42):
        super().__init__()
        self._num_partitions = num_partitions
        self._groups = groups
        self._seed = seed
        self._assignments: dict[int, np.ndarray] | None = None

    @property
    def num_partitions(self) -> int:
        return self._num_partitions

    @staticmethod
    def _split(
        indices: np.ndarray,
        clients: list[int],
        weights: np.ndarray,
        rng: np.random.Generator,
    ) -> dict[int, np.ndarray]:
        """Split (shuffled) sample indices across clients by relative weight."""
        indices = np.array(indices)
        rng.shuffle(indices)
        weights = np.asarray(weights, dtype=float)
        if weights.sum() <= 0:
            weights = np.ones(len(clients))
        weights = weights / weights.sum()
        cuts = (np.cumsum(weights)[:-1] * len(indices)).astype(int)
        splits = np.split(indices, cuts)
        return {client: split for client, split in zip(clients, splits)}

    def _pathological_assign(
        self, group: dict, rng: np.random.Generator
    ) -> dict[int, list[int]]:
        """Decide which classes each client in a pathological group holds."""
        clients = group["clients"]
        pool = list(group["classes"])
        n = group["num_classes_per_partition"]
        mode = group.get("class_assignment_mode", "deterministic")
        client_classes: dict[int, list[int]] = {}
        for i, cid in enumerate(clients):
            if mode == "deterministic":
                chosen = [pool[(i * n + j) % len(pool)] for j in range(n)]
            elif mode == "first-deterministic":
                first = pool[i % len(pool)]
                others = [c for c in pool if c != first]
                extra = rng.choice(
                    others, size=min(n - 1, len(others)), replace=False
                )
                chosen = [first, *(int(x) for x in extra)]
            else:  # random
                chosen = [
                    int(x)
                    for x in rng.choice(pool, size=min(n, len(pool)), replace=False)
                ]
            # Deduplicate while preserving order (n may exceed the pool size).
            client_classes[cid] = list(dict.fromkeys(chosen))
        return client_classes

    def _compute_assignments(self) -> None:
        rng = np.random.default_rng(self._seed)
        labels = np.array(self.dataset["label"])
        assignments: dict[int, list[int]] = {
            cid: [] for cid in range(self._num_partitions)
        }

        for group in self._groups:
            clients = group["clients"]
            strategy = group["strategy"]

            if strategy == "explicit":
                assignment = group["assignment"]
                pool = _group_class_pool(group)
                holders_for = {
                    cls: [c for c in clients if cls in assignment[c]] for cls in pool
                }
            elif strategy == "pathological":
                client_classes = self._pathological_assign(group, rng)
                pool = group["classes"]
                holders_for = {
                    cls: [c for c in clients if cls in client_classes[c]]
                    for cls in pool
                }
            else:  # iid / dirichlet: every client in the group holds every class
                pool = group["classes"]
                holders_for = {cls: list(clients) for cls in pool}

            for cls in pool:
                holders = holders_for[cls]
                if not holders:
                    continue
                cls_indices = np.where(labels == cls)[0]
                if strategy == "dirichlet":
                    weights = rng.dirichlet(np.full(len(holders), group["alpha"]))
                else:
                    weights = np.ones(len(holders))
                for cid, split in self._split(
                    cls_indices, holders, weights, rng
                ).items():
                    assignments[cid].extend(split.tolist())

        self._assignments = {
            cid: np.array(sorted(idx), dtype=int) for cid, idx in assignments.items()
        }

    def load_partition(self, partition_id: int) -> Dataset:
        if self._assignments is None:
            self._compute_assignments()
        indices = self._assignments[partition_id]
        if len(indices) == 0:
            raise ValueError(
                f"Client {partition_id} was assigned 0 samples by the scenario; "
                "check its class pool / assignment."
            )
        return self.dataset.select(indices)


def create_partitioner(scenario: dict, num_partitions: int) -> ScenarioPartitioner:
    """Build a ScenarioPartitioner from a validated scenario dict."""
    return ScenarioPartitioner(
        num_partitions=num_partitions,
        groups=scenario["groups"],
        seed=scenario["seed"],
    )


def apply_label_noise(
    dataset: Dataset,
    fraction: float,
    num_classes: int,
    seed: int,
    partition_id: int,
) -> Dataset:
    """Symmetrically flip a fraction of labels to a random *different* class.

    Deterministic per (seed, partition_id) so repeated loads agree.
    """
    rng = np.random.default_rng([seed, partition_id])
    labels = np.array(dataset["label"])
    n = len(labels)
    n_flip = int(round(fraction * n))
    if n_flip == 0:
        return dataset
    flip_idx = rng.choice(n, size=n_flip, replace=False)
    new_labels = labels.copy()
    for i in flip_idx:
        offset = rng.integers(1, num_classes)  # 1..num_classes-1 => always different
        new_labels[i] = (labels[i] + offset) % num_classes

    def _relabel(example, idx):
        example["label"] = int(new_labels[idx])
        return example

    return dataset.map(_relabel, with_indices=True)


def _scenario_title(scenario: dict) -> str:
    """One-line human-readable summary of the scenario's groups."""
    parts = []
    for group in scenario["groups"]:
        strategy = group["strategy"]
        if strategy == "dirichlet":
            label = f"dirichlet(α={group['alpha']})"
        elif strategy == "pathological":
            label = f"pathological({group['num_classes_per_partition']}/client)"
        else:
            label = strategy
        parts.append(f"{label}: clients {group['clients']}")
    title = " | ".join(parts)
    if scenario["label_noise"]:
        title += f"  +noise {dict(scenario['label_noise'])}"
    return title


def load_data(
    partition_id: int,
    num_partitions: int,
    batch_size: int,
    scenario_config_path: str,
):
    """Load partition CIFAR10 data according to the scenario config."""
    global fds, _fds_key
    scenario = load_scenario_config(scenario_config_path, num_partitions)

    # Only (re)initialize `FederatedDataset` when the scenario/size changes.
    cache_key = (str(_resolve_scenario_path(scenario_config_path)), num_partitions)
    if fds is None or _fds_key != cache_key:
        partitioner = create_partitioner(scenario, num_partitions)
        fds = FederatedDataset(
            dataset="uoft-cs/cifar10",
            partitioners={"train": partitioner},
        )
        _fds_key = cache_key

    partition = fds.load_partition(partition_id)

    # Apply per-client label noise, if configured for this client.
    noise_fraction = scenario["label_noise"].get(partition_id)
    if noise_fraction:
        partition = apply_label_noise(
            partition,
            noise_fraction,
            scenario["num_classes"],
            scenario["seed"],
            partition_id,
        )

    # Divide data on each node: 80% train, 20% test
    partition_train_test = partition.train_test_split(test_size=0.2, seed=42)
    # Construct dataloaders
    partition_train_test = partition_train_test.with_transform(apply_transforms)
    trainloader = DataLoader(
        partition_train_test["train"], batch_size=batch_size, shuffle=True
    )
    testloader = DataLoader(partition_train_test["test"], batch_size=batch_size)
    return trainloader, testloader


def plot_partition_distribution(
    num_partitions: int,
    scenario_config_path: str,
    save_path: str = "partition_distribution.png",
):
    """Create and save a plot showing how classes are divided over clients."""
    import matplotlib
    matplotlib.use("Agg")  # non-interactive backend
    import matplotlib.pyplot as plt

    scenario = load_scenario_config(scenario_config_path, num_partitions)
    partitioner = create_partitioner(scenario, num_partitions)
    # We need to attach the partitioner to a dataset to generate the partitions
    fds_plot = FederatedDataset(
        dataset="uoft-cs/cifar10",
        partitioners={"train": partitioner},
    )
    # Access partitioner from the FederatedDataset so it is properly loaded
    loaded_partitioner = fds_plot.partitioners["train"]

    fig, ax, df = plot_label_distributions(
        partitioner=loaded_partitioner,
        label_name="label",
        plot_type="bar",
        size_unit="absolute",
        partition_id_axis="x",
        legend=True,
        title=f"Class Distribution — {_scenario_title(scenario)}",
    )
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Server] Saved partition distribution plot → {save_path}")
    return save_path


def load_centralized_dataset():
    """Load test set and return dataloader."""
    # Load entire test set
    test_dataset = load_dataset("uoft-cs/cifar10", split="test")
    dataset = test_dataset.with_format("torch").with_transform(apply_transforms)
    return DataLoader(dataset, batch_size=128)


def train(net, trainloader, epochs, lr, device):
    """Train the model on the training set."""
    net.to(device)  # move model to GPU if available
    criterion = torch.nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.Adam(net.parameters(), lr=lr)
    net.train()
    running_loss = 0.0
    for _ in range(epochs):
        for batch in trainloader:
            images = batch["img"].to(device)
            labels = batch["label"].to(device)
            optimizer.zero_grad()
            loss = criterion(net(images), labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
    avg_trainloss = running_loss / (epochs * len(trainloader))
    return avg_trainloss


def evaluate(net, testloader, device, num_classes: int = 10):
    """Validate the model on the test set.

    Returns ``(loss, accuracy, confusion)`` where ``confusion`` is a
    ``num_classes x num_classes`` integer matrix with true labels on the rows
    and predicted labels on the columns.
    """
    net.to(device)
    net.eval()  # BatchNorm/Dropout must use running stats, not batch stats
    criterion = torch.nn.CrossEntropyLoss()
    correct, loss = 0, 0.0
    confusion = np.zeros((num_classes, num_classes), dtype=np.int64)
    with torch.no_grad():
        for batch in testloader:
            images = batch["img"].to(device)
            labels = batch["label"].to(device)
            outputs = net(images)
            loss += criterion(outputs, labels).item()
            preds = torch.max(outputs.data, 1)[1]
            correct += (preds == labels).sum().item()
            # Accumulate true/pred pairs via a flat bincount (one host sync per
            # batch rather than one per sample).
            flat = labels * num_classes + preds
            confusion += (
                torch.bincount(flat.view(-1), minlength=num_classes**2)
                .cpu()
                .numpy()
                .reshape(num_classes, num_classes)
            )
    accuracy = correct / len(testloader.dataset)
    loss = loss / len(testloader)
    return loss, accuracy, confusion


def test(net, testloader, device):
    """Validate the model on the test set, returning ``(loss, accuracy)``."""
    loss, accuracy, _ = evaluate(net, testloader, device)
    return loss, accuracy
